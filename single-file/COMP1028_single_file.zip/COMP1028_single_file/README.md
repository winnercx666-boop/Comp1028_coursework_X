# COMP1028 Single-File Source and Run Package

This package contains the complete document-search application in one source file, `coursework.c`. Shared types, prototypes, document input, indexing, ranking, Feature 6, Feature 9 and the console menu are in that file. No project-specific header files or additional production C files are needed to compile it.

## Find Features 6 and 9

- Feature 6 starts at line 550: search for `FEATURE 6: STATISTICS AND REPORTING`. This section contains collection/per-document/index statistics and TXT/CSV reports.
- Feature 9 starts at line 881 immediately after Feature 6: search for `FEATURE 9: PERSISTENT INDEX`. This section contains the file format, save/load, record validation and failed-load cleanup.
- The shared structures are near the beginning; the menu and main function follow Feature 9.
- The implementation retains separate functions within the single source file. Two file-local persistence helpers have module prefixes to avoid name collisions.

## Run the supplied Windows program

Extract the whole package and double-click `run.cmd` from this folder. It starts the supplied `coursework.exe`, which enables the existing folder-input adapter.

1. At `Choice:`, enter `1`.
2. At the path prompt, enter `examples/documents`. Menu numbers belong at `Choice:`; the path prompt requires a document folder or collection-list filename.
3. Enter `3` to display statistics. The sample contains 3 documents, 5 term occurrences, 3 unique terms and 4 posting relationships.
4. Enter `4`, search for `apple`, press Enter for Top K = 5, and enter `/exit` to return.
5. Enter `6` or `7`, then press Enter to save `report.txt` or `report.csv`.
6. Enter `8`, then press Enter to save `index.idx`.
7. Enter `0` to exit. Restart, enter `9` and press Enter to restore `index.idx`; statistics, search and preview are available without rebuilding.

For an actual corpus, enter its document-folder path or configured collection-list path at the loading prompt. Relative paths use this package folder when launched through `run.cmd`.

## Compile only coursework.c

Standard-C collection-list build:

```powershell
gcc -std=c17 -O2 -Wall -Wextra -Wpedantic coursework.c -o coursework_standard.exe
.\coursework_standard.exe
```

Select option 1 and enter `examples/collection.txt`. This build uses standard C library interfaces and does not require `dirent.h`.

Optional original folder adapter, when the compiler supplies `dirent.h`:

```powershell
gcc -DENABLE_DIRECTORY_INPUT -std=c17 -O2 -Wall -Wextra -Wpedantic coursework.c -o coursework.exe
.\coursework.exe
```

Compile this source by itself. All production functions are already included in it.

## Validation performed on 26 November 2026

- Both single-file variants compiled with C17, -O2, -Wall, -Wextra, -Wpedantic and -Werror.
- Existing contract tests passed 1012 assertion/required-allocation/file-I/O checks, with 0 failures and 21 malformed-index variants.
- All 28 existing menu/process checks passed, including CSV parsing, failed-load preservation, restart without the original corpus and a synthetic 50-document/100000-occurrence collection.
- A static comparison confirmed all five production modules and four shared headers were preserved, except for the two internal helper renames and consolidated includes.
- The indexing/scoring behavior and version-1 persistence format are unchanged. The original project license is preserved.

These are functional and synthetic-scale checks. The coursework-prescribed dataset evaluation and final benchmark remain separate work.

## Submission contents

Use `coursework.c` for the source-code component of submission. The package also contains the Windows executables, sample input/configuration, launcher, license and validation summary. Complete reports, logs, benchmark results and video links remain separate course deliverables.

